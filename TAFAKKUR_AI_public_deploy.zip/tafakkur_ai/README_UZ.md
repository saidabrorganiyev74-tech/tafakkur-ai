# TAFAKKUR.AI — internetga joylashtirish

## 1. GitHub'ga yuklash
1. ZIP faylni oching.
2. Ichidagi `tafakkur_ai` papkasidagi fayllarni yangi GitHub repository'ga yuklang.
3. `.env` faylini hech qachon GitHub'ga yuklamang. `.env.example` namunadir.

## 2. Render'da joylashtirish
1. Render hisobiga kiring (yoshga oid shartlar bo'lsa, ota-ona/vasiy bilan).
2. New > Web Service ni tanlang.
3. GitHub repository'ni ulang.
4. Runtime: Node, Build Command: `npm install`, Start Command: `npm start`.
5. Free rejani tanlang va deploy qiling.
6. Sayt `https://...onrender.com` manzilida ochiladi.

## 3. Haqiqiy AI'ni ulash
Render servisida Environment bo'limiga:
- `OPENAI_API_KEY` = maxfiy API kaliti
- `OPENAI_MODEL` = `gpt-4.1-mini`

Kalitni HTML/JS yoki GitHub'ga yozmang. API ishlatish xarajat keltirishi mumkin; limit va billingni kattalar bilan tekshiring.

## Bepul hosting cheklovlari
Render Free servis 15 daqiqa so'rov bo'lmasa uxlab qoladi; keyingi kirishda taxminan bir daqiqa uyg'onishi mumkin. Bepul rejani ishlab chiqarishdagi muhim xizmat uchun emas, sinov va kichik loyiha uchun ishlating.
