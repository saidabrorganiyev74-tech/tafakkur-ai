const form = document.getElementById("chatForm");
const input = document.getElementById("prompt");
const messages = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const sendBtn = document.getElementById("sendBtn");

function addMessage(role, text) {
  welcome.style.display = "none";
  const item = document.createElement("div");
  item.className = `message ${role}`;
  const label = document.createElement("span");
  label.className = "message-label";
  label.textContent = role === "user" ? "SIZ" : "TAFAKKUR.AI";
  const body = document.createElement("div");
  body.textContent = text;
  item.append(label, body);
  messages.appendChild(item);
  item.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function sendMessage(text) {
  const message = text.trim();
  if (!message) return;
  addMessage("user", message);
  input.value = "";
  sendBtn.disabled = true;
  const waiting = document.createElement("div");
  waiting.className = "message ai";
  waiting.textContent = "TAFAKKUR.AI javob tayyorlamoqda...";
  messages.appendChild(waiting);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    const data = await response.json();
    waiting.remove();
    if (!response.ok) throw new Error(data.error || "Server xatosi.");
    addMessage("ai", data.reply);
  } catch (error) {
    waiting.remove();
    addMessage("ai", error.message + " Serverni ishga tushirganingizni va API sozlamalarini tekshiring.");
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});
document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
document.getElementById("newChat").addEventListener("click", () => {
  messages.replaceChildren();
  welcome.style.display = "";
  input.value = "";
});
document.getElementById("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
});
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
