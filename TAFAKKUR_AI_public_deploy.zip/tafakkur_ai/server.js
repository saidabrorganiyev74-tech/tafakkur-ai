require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ error: "Xabar bo‘sh." });
    if (message.length > 4000) {
      return res.status(400).json({ error: "Xabar juda uzun (maksimum 4000 belgi)." });
    }
    if (!client) {
      return res.status(503).json({
        error: "AI hali ulanmagan. .env fayliga API kalitini xavfsiz qo‘shing yoki demo rejimidan foydalaning."
      });
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "Sen TAFAKKUR.AI yordamchisisan. O‘zbek tilida aniq, foydali va muloyim javob ber. Bilmagan narsangni to‘qib chiqarmagin.",
      input: message
    });

    res.json({ reply: response.output_text || "Javob olinmadi. Qayta urinib ko‘ring." });
  } catch (error) {
    console.error("Chat API xatosi:", error.message);
    res.status(500).json({ error: "Hozir javob berib bo‘lmadi. Birozdan keyin urinib ko‘ring." });
  }
});

const port = Number(process.env.PORT) || 3000;
app.listen(port, "0.0.0.0", () => {
  console.log(`TAFAKKUR.AI: http://localhost:${port}`);
});
